


				 _     ____  _   _ _____ 
				| |   |  _ \| \ | |___  |
				| |   | | | |  \| |  / / 
				| |___| |_| | |\  | / /  
				|_____|____/|_| \_|/_/ 

				Domača naloga za RK

				Avtor:        Lan Vukušič
				Vpisna št:    63190321
				Verzija:      1.0
				Datum oddaje: 1.5.2020





1)
	v datotekah chatClient in chatServer nastavite polji:

	PORT = 1234
	IP  = "192.168.1.12"
	popravite IP z ustreznim IP naslovom naprave

	zaženite server na izbranem računalniku

	zaženite cliente na ostalih napravah



2)
	Client vas bo prosil za unikatno uporabniško ime (case sensitive)

	karkoli boste vpisali bo poslano vsem ostalim clientom

	če hočete zamenjati naslovnika, to naredite z komando !{ime}
	Če hočete spet pošiljati vsem to naredite z !@



3)

	Navodila lahko vidite tudi z ukazom !help





