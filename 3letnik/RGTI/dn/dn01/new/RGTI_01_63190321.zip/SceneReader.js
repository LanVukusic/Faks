"use strict";

export class SceneReader {
  static readFromJson(json) {
    return JSON.parse(json);
  }
}
