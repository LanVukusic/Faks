#!/bin/bash
tensorboard dev --logdir logs/fit --name uozp_board